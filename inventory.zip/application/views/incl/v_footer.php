<footer class="footer">
	© <?= date('Y') ?> KAWA COFFEE <span class="d-none d-md-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i> by Codeigniter 3.11.</span>
</footer>