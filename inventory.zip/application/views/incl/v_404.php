<div class="ex-page-content text-center">
                                    <h1 class="text-primary">4<i class="far fa-smile text-success ml-1 mr-1"></i>4!</h1>
                                    <h4 class="">Sorry, page not found</h4><br>
            
                                    <a class="btn btn-primary mb-5 waves-effect waves-light" href="index.html">Back to Dashboard</a>
                                </div>